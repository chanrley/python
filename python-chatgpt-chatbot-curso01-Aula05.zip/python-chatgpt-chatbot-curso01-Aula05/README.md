## Desafio: Gerador de e-mail de Recomendação de Produtos

1. Identificar perfis a partir de uma lista de compras recentes por clientes
2. Para cada cliente:
    * Recomendar 3 produtos para o perfil a partir de uma lista de produtos
    * Escrever um e-mail de recomendação dos produtos escolhidos com até 3 parágrafos

